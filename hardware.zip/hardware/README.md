# lucidgloves-hardware


Here are the 3D models for your printed glove parts.
The x.1 versions have slight tweaks over their counterparts to make them more easily printable and durable, so prefer those when available.
If you are on the fence between having haptics or not, you can print the Prototype v4 without servos and add them later.

Check the [printing guides](https://github.com/LucidVR/lucidgloves/wiki/Parts-Printing-Guide) to know how many you need to print and how.
